<header>
    <div class="container logo">
        <a href="#"><img src="https://carestaffservices.com/wp-content/uploads/2023/07/New-Logo.png" width="200px" alt="Care Staff Services Ltd"></a>
        <h1>Care Staff Services LTD</h1>
    </div>
</header>
<form id="multistepsform" class="bg-light p-4 rounded">
    <!-- progressbar -->
    <ul id="progressbar" class="list-unstyled d-flex justify-content-between">
        <li class="active" style="display: none">Account Setup</li>
        <li class="active">Personal Details</li>
        <li>Social Profiles</li>
        <li>Social Profiles</li>
        <li>Social Profiles</li>
        <li>Social Profiles</li>
    </ul>
    <!-- fieldsets -->
</form>
