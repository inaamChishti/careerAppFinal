<?php $__env->startSection('content'); ?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<div class="container">

    <div class="row justify-content-center">



        <div class="col-md-8">
            <?php if(@$request['error']): ?>
    <div class="alert alert-danger">
       <?php echo e(@$request['error']); ?>

    </div>
    <?php endif; ?>
            <div class="card">
                <div class="card-header"><?php echo e(__('Enter Verification Code')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('verify_code')); ?>" id="verificationForm">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" readonly name="email" value="<?php echo e($email); ?>">
                        <div class="mb-3">
                            <label for="verification_code" class="form-label">Verification Code</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['verification_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="verification_code" name="verification_code" required>
                            <div class="invalid-feedback" id="verification-code-feedback"></div>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\careerApp\resources\views/verification.blade.php ENDPATH**/ ?>