<header>
    <div class="container logo">
        <a href="#"><img src="https://carestaffservices.com/wp-content/uploads/2023/07/New-Logo.png" width="200px" alt="Care Staff Services Ltd"></a>
        <h1>Care Staff Services LTD</h1>
    </div>
</header>
<form id="multistepsform" class="bg-light p-4 rounded" style="zoom:0.8;">
    <!-- progressbar -->
    <ul id="progressbar" class="list-unstyled d-flex justify-content-between">
        <li class="active" style="display: none">Account Setup</li>
        <li <?php if(isset($pageTitle) && $pageTitle == 1): ?> class="active" <?php endif; ?>>Home</li>
        <li <?php if(isset($pageTitle) && $pageTitle == 2): ?> class="active" <?php endif; ?>>Terms & Conditions</li>
        <li <?php if(isset($pageTitle) && $pageTitle == 3): ?> class="active" <?php endif; ?>>Profiles</li>
        <li <?php if(isset($pageTitle) && $pageTitle == 4): ?> class="active" <?php endif; ?>>Experience & Job</li>
        <li <?php if(isset($pageTitle) && $pageTitle == 5): ?> class="active" <?php endif; ?>>Social Profiles</li>
        

    </ul>
    <!-- fieldsets -->
</form>
<?php /**PATH C:\xampp\htdocs\careerApp\resources\views/header.blade.php ENDPATH**/ ?>