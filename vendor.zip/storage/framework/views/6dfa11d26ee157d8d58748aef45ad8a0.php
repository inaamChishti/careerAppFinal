<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Add the CSS import for Bootstrap Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.4.0/font/bootstrap-icons.min.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Custom CSS -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <style>
        @import url(https://unpkg.com/@webpixels/css@1.1.5/dist/index.css);
    </style>

    <!-- Latest version of Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">


    <!-- Add the CSS import for Bootstrap Icons -->
    <style>
        @import url("https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.4.0/font/bootstrap-icons.min.css");
    </style>
 <style>
    @import url("https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.4.0/font/bootstrap-icons.min.css");
</style>
<style>
    /* Custom Styles */
    body {
        padding-top: 60px;
        /* Add padding to the top of the body to make space for the header */
    }

    .sidebar {
        position: fixed;
        top: 60px;
        /* Place the sidebar below the header */
        bottom: 0;
        left: 0;
        width: 250px;
        /* Set the width of the sidebar */
        padding-top: 1rem;
        /* Add some padding to the top of the sidebar */
        background-color: #f8f9fa;
        /* Set the background color of the sidebar */
    }
    @media (max-width: 767px) {
    .sidebar {
        position: relative; /* Change to 'position: relative;' for mobile screens */
    }
}
    /* Adjust the container's margin to make space for the sidebar */
    .container {
        margin-left: 250px;
        /* Should be equal to the width of the sidebar */
    }

    /* below is logout css */
    /* Styles for the current user name (white color) */
    #navbarDropdown {
        color: white;
    }

    /* Styles for the toggle button (using Bootstrap classes) */
    .dropdown-menu-end .dropdown-item {
        display: flex;
        align-items: center;
    }

    .dropdown-menu-end .dropdown-item:hover {
        background-color: #D361B3;
        /* Add a background color on hover */
    }

    .dropdown-menu-end .dropdown-item .bi {
        margin-right: 5px;
    }

    /*  */
    body {
        padding-top: 60px;
        /* Add padding to the top of the body to make space for the header */
    }

    /* Ensure the header stays on top */
    .header {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background-color: #292222;
        color: white;
        text-align: center;
        padding: 0px;
        z-index: 100;
    }

    .sidebar {
        /* ... Your existing styles ... */
        z-index: 50;
        /* Set z-index to a higher value than the main content to ensure it stays on top */
    }

    .main-content {
        /* ... Your existing styles ... */
        z-index: 0;
        /* Set z-index to 0 to ensure it stays below the fixed header and sidebar */
        position: relative;
        /* Add position relative to ensure correct stacking context */
    }

    /* Inline styles for demonstration purposes. It's better to use an external CSS file in a real project. */
    .nav-item.dropdown {

        position: relative;
    }

    .dropdown-menu {
        position: absolute;
        right: 0;
    }

    /* Your regular link styles */
    .nav-link {
        color: #333;
        /* Change to your preferred color */
    }

    /* Active link styles */
    .nav-item.active .nav-link {
        color: #000000;
        /* Change to your preferred active color */
        background-color: #a0b0b361;
        /* Change to your preferred active background color */
    }

    /* Hover effect */
    .nav-item:not(.active):hover .nav-link {
    color: black;
    /* Change to your preferred hover text color */
    background-color: #D361B3;
    /* Keep the background color if desired */
    /* Add any other hover styles as needed */
}

@media (max-width: 767px) {
            .sidebar {
                position: relative;
                width: 100%;
                margin-top: 0;
            }

            .container {
                margin-left: 0;
            }

            .navbar {
                position: relative;
            }
        }
</style>
</head>
<body >
   <div id="app">
            
            <div class="header" style="display: flex; justify-content: space-between; align-items: center; background-color: #D361B3; color: white; padding: 10px;">
                <div class="logo" style="display: flex; align-items: center;">
                    <img src="https://carestaffservices.com/wp-content/uploads/2023/07/New-Logo.png" alt="Logo" style="width: 250%; height: 40px; margin-right: 10px; filter: brightness(0.5) grayscale(100%);">
                </div>


                <div class="menu" style="display: flex; align-items: center;">
                    <ul style="list-style: none; display: flex; align-items: center; margin: 0;">

                        <li style="margin-left: 20px;">
                            <a href="<?php echo e(url('logout')); ?>" style="color: white; text-decoration: none;"
                                onclick="logout()"> <b style="color: black">Logout</b> </a>
                        </li>
                    </ul>
                </div>

            </div>
            <!-- Rest of your content goes here -->


            

        <div class="sidebar"  style=" margin-top: -22px;">
<!-- Dashboard -->
<div  style="background-color:#535353;" class="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
    <!-- Vertical Navbar -->
    <nav class="navbar show navbar-vertical h-lg-screen navbar-expand-lg px-0 py-3 navbar-light bg-white border-bottom border-bottom-lg-0 border-end-lg" id="navbarVertical">
        <div class="container-fluid">
            <!-- Toggler -->
            <button class="navbar-toggler ms-n2" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarCollapse" aria-controls="sidebarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Brand -->

            <div class="offset-md-2" style="display: flex; align-items: flex-end;">
                <i>
                  
                  <b><?php echo e(\Carbon\Carbon::now()->format('l j M Y')); ?></b>
                </i>
              </div>
            <hr>
            <!-- User menu (mobile) -->

            <!-- Collapse -->

            <div class="collapse navbar-collapse offset-md-1" id="sidebarCollapse">
                <!-- Navigation -->
                <ul class="navbar-nav">
                    

                    <li class="mt-2 nav-item <?php echo e(request()->is('adminDashboard') ? 'active' : ''); ?>" style="background-color: #D361B3;height: 30px; position: relative;">
                        <a class="nav-link" href="<?php echo e(url('adminDashboard')); ?>" style="height: 30px; text-decoration: none;">
                            <i class="bi bi-house"></i> <b>Dashboard</b> <i class="fa fa-arrow-right" style="position: absolute; right: 6px;  font-weight: bold; color: black;"></i>
                        </a>
                        




                    </li>

                    <script>
                        const navItem = document.querySelector('.nav-item');
                        const popupList = document.getElementById('popupList');

                        navItem.addEventListener('mouseenter', () => {
                            popupList.style.display = 'block';
                        });

                        navItem.addEventListener('mouseleave', () => {
                            popupList.style.display = 'none';
                        });
                    </script>


                    
                    <li class=" mt-2 nav-item <?php echo e(request()->is('application-request') ? 'active' : ''); ?>" style="background-color: #D361B3;height: 30px; position: relative;">
                        <a class="nav-link" href="<?php echo e(url('application-request')); ?>" style="height: 30px;">
                            <i class="fas fa-calendar-alt"></i> Application Request
                        </a>
                    </li>

                </ul>
                <!-- Divider -->

                <!-- Navigation -->

                <!-- Push content down -->
                <div class="mt-auto"></div>
                <!-- User (md) -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="bi bi-person-square"></i> Account
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="bi bi-box-arrow-left"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Main content -->

</div>
        </div>


        <main class="py-4">
            <div class="main-content" style="wdth:100%;height:100%;"> <!-- Add the "main-content" class to the main content container -->
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\careerApp\resources\views/layouts/admin.blade.php ENDPATH**/ ?>